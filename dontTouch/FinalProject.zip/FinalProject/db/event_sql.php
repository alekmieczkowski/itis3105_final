<?php
#import database
include('dataBase.php');

/*
Admin SQL queries

- Add an event 
- Delete an event 
- Register/unregister for an event
- View events 
- View registered events
- Users can choose from different times and locations for a certain event

*/
session_start();

/*
Get all Events
*/
function sql_getEvents(){

    $db = db::getInstance();
    $stm=$db->prepare("select * from activities");
    $stm->execute();
    $events=$stm->fetchAll();

    return $events;
}

/*
Get Event image
*/
function sql_getEventImage($eventID){
    
        $db = db::getInstance();
        $stm=$db->prepare("select image from activities where activityID=".$eventID);
        $stm->execute();
        $event_img=$stm->fetch();
        header('Content-type: image/jpg');
        return $event_img;
    }

/*
Delete Event
*/
function sql_delEvent($eventID){
    $db = db::getInstance();
    $sql = "Delete from reg_activities where regID=$eventID";
    $stm=$db->prepare($sql);
    $stm->execute();

    return true;
}

/*
Register for event
*/

function sql_registerEvent($userID, $eventID){
    $db = db::getInstance();
    $sql = "Insert into reg_activities (userID, regID) VALUES(".$userID.",".$eventID.")";
    $stm=$db->prepare($sql);
    $stm->execute();

    return true;
}

/*
Unregister for event
*/

function sql_unregisterEvent($regID){
    $db = db::getInstance();
    $sql = "Delete from reg_activities where regID=".$regID;
    $stm=$db->prepare($sql);
    $stm->execute();

    return true;
}

/*
Get All registered Events
*/
function sql_getRegisteredEvents(){

    $db = db::getInstance();
    $sql = "Select * from reg_activities";
    $stm=$db->prepare($sql);
    $stm->execute();
    $events=$stm->fetchAll();

    return $events;

}

/*
Get Registered Events by User ID
*/
function sql_getUserEvents(){
    $userID=3;
    
    $db = db::getInstance();
    $sql = "Select * from reg_activities where userID=".$userID;
    $stm=$db->prepare($sql);
    $stm->execute();
    $events=$stm->fetchAll();

    return $events;

}


function sql_getRegisteredEventsForUser2(){
    $userID=$_SESSION['userID'];


    $db = db::getInstance();
    $sql = "Select * from reg_activities join activities on actID=activityID where userID=".$userID;
    $stm=$db->prepare($sql);
    $stm->execute();
    $events=$stm->fetchAll();

    return $events;

}


function sql_getEvents22(){

    $db = db::getInstance();
    $stm=$db->prepare("select * from activities");
    $stm->execute();
    $events=$stm->fetchAll();

    return $events;
}



/*
Get all dates for certain event, and order by date
*/
function sql_getSameEvents($eventName){
    $db = db::getInstance();
    $sql = "Select * from activities where a_name=".$eventName."ORDER BY a_date";
    $stm=$db->prepare($sql);
    $stm->execute();
    $events=$stm->fetchAll();

    return $events;
}

function sql_editEvent()


{
    $db=db::getInstance();
    $stm1=$db->prepare('update activities set a_name=?, description=?, price=?,min_age=?, a_date=?, location=?, image=? WHERE activityID=?');
    $stm1->bindValue(1,$_POST['name']);
    $stm1->bindValue(2,$_POST['description']);
    $stm1->bindValue(3,$_POST['price']);
    $stm1->bindValue(4,$_POST['age']);
    $stm1->bindValue(5,$_POST['date']);
    $stm1->bindValue(6,$_POST['location']);
    $stm1->bindValue(7,$_POST['image']);
    $stm1->bindValue(8,1);
    $stm1->execute();


}



#image render
if(isset($_GET['imageBlob'])){
    header('Content-type: image/jpg');
    echo $data['myImage'];
}







?>