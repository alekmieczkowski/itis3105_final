<?
$current_dir = basename(dirname(__FILE__));
include("../header.php");

echo $test;
?>