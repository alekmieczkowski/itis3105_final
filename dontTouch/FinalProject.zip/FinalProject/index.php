<?php
/*
*
 * Created by PhpStorm.
 * User: Mohamed
 * Date: 11/16/2017
 * Time: 7:08 PM
 */

//redirect to site/index.php
Header("Location: site/home.php");

?>

