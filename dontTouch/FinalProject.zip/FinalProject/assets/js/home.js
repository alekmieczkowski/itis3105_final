
//On Document start
$( document ).ready(function() {

    //curved text for logo header
    var $header	= $('#header').hide();
    $header.show().arctext({radius: 600});
});